require "test/unit"
require "mocha"
require "proxies"

class Proxies::TestCase < Test::Unit::TestCase
  include Proxies
end
