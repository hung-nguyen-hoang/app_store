require "proxies/proxy"

module Proxies

end
