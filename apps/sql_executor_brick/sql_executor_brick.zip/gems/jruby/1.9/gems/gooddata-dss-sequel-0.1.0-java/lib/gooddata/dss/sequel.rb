require 'rubygems'
require 'sequel'
require 'jdbc/dss'

module GoodData
  class DSS
    # Creates a Sequel database object based on the supplied connection string
    # and optional arguments.
    #
    # Examples:
    #
    #   url  = 'jdbc:dss:na1.secure.gooddata.com/gdc/dss/instances/abcd123'
    #
    #   conn = DSS.sequel(url, :user => 'username@example.org', :password => 'secret')
    #
    #   DSS.sequel(url, :user => 'username@example.org', :password => 'secret') do |conn|
    #      # do sequel stuff
    #   end
    def self.sequel(*args, &block)
      Sequel.connect(*args, &block)
    end
  end
end
