module GoodData
  module DSS
    module Sequel
      VERSION = '0.1.0'
    end
  end
end
