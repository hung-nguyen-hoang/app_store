begin
  JRUBY_VERSION.nil?
rescue
  warn 'Jdbc-DSS is only for use with JRuby'
end

require 'jdbc/dss/version'

# JDBC Wrapper
module Jdbc
  # DSS Wrapper
  module DSS
    def self.driver_jar
      "dss-jdbc-driver-#{DRIVER_VERSION}.jar"
    end

    def self.load_driver(method = :load)
      send method, driver_jar
    end

    def self.driver_name
      'com.gooddata.dss.jdbc.driver.DssDriver'
    end

    if defined?(JRUBY_VERSION) && # enable backwards-compat behavior :
       (Java::JavaLang::Boolean.get_boolean('jdbc.driver.autoload') ||
         Java::JavaLang::Boolean.get_boolean('jdbc.dss.autoload'))
      warn "autoloading JDBC driver on require 'jdbc/dss'" if $VERBOSE
      load_driver :require
    end
  end
end
