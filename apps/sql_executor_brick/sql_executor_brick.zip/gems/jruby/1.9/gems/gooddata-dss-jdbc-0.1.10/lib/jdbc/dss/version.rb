# encoding: utf-8

# JDBC Wrapper
module Jdbc
  # DSS Wrapper
  module DSS
    DRIVER_VERSION = '2.7.1'
    VERSION = '0.1.10'
  end
end
