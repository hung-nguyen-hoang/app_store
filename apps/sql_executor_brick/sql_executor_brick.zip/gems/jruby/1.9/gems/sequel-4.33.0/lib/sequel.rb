# frozen-string-literal: true

require 'sequel/model'
