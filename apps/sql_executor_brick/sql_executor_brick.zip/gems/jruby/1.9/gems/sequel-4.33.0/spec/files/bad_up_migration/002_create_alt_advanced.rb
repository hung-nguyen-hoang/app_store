Sequel.migration do
  up{get(:asdfassfd)}
end
