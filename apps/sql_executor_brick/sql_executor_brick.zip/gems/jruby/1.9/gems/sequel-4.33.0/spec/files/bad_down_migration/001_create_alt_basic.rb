Sequel.migration do
  up{create_table(:sm11111){Integer :smc1}}
  down{get(:asdfsadfsa)}
end
