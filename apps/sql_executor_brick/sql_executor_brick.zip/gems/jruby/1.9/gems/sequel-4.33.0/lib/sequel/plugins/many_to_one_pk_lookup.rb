# frozen-string-literal: true

module Sequel
  module Plugins
    # Empty plugin module for backwards compatibility
    module ManyToOnePkLookup
    end
  end
end
