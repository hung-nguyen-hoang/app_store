# frozen-string-literal: true

require 'sequel'
