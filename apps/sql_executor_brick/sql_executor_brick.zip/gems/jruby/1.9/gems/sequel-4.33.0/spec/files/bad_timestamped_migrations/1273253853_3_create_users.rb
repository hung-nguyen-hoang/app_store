Sequel.migration do
  up{get(:asdfsadfas)}
end
