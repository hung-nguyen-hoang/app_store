# frozen-string-literal: true

Sequel.require 'adapters/postgres'
