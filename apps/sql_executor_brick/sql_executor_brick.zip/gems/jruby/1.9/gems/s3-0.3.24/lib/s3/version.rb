module S3
  VERSION = "0.3.24"
end
