module Peach
  VERSION = "0.5.1"
end
